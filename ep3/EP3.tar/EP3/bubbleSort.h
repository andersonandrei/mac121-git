#include <stdlib.h>
#include <stdio.h>

/* Recebe um ponteiro para um vetor, um inteiro
 * n representando seu tamanho e ordena esse vetor
 * utilizando essensialmente o algoritmo 
 * Bubble Sort */
void bubbleSort(int *v, int n);
